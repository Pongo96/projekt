//required packages
const Iota = require('@iota/core');
const Converter = require('@iota/converter');
const Extract = require('@iota/extract-json');

//select a node to connect to
iota = Iota.composeAPI({
    provider: 'https://nodes.devnet.iota.org:443'
});

//defining seed of the sender
const seed = '9XEJ9YLPZFXCPUZBPXC9BFZOIAUPRFHKIVEFZYQEWDGKYIXCBJTTGCPATGGMRSRX9JOYBANGFFTYGIDBP';
const depth = 3;
const minimumWeightMagnitude = 9;

//define receiving address and the message
const receivingAddress = 'HEQLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWOR99D';
var lastFertilizerTx = ""
var lastPesticideTx = ""
var lastProductTx = ""

async function pesticideApplication(json, callback) {
    json.pesticides.previousPesticideApplication = lastPesticideTx
    const txHash = await sendTransaction(json)
    lastPesticideTx = txHash
    return {transactionHash: txHash}
}

async function fertilizerApplication(json, callback) {
    json.fertilisers.previousFertiliserApplication = lastFertilizerTx
    const txHash = await sendTransaction(json)
    lastFertilizerTx = txHash
    return {transactionHash: txHash}
}

async function registerProduct(json) {
    json.previousProduct = lastProductTx
    const txHash = await sendTransaction(json)
    lastProductTx = txHash
    return {transactionHash: txHash}
}

async function sendTransaction(json) {
    const productJSON = JSON.stringify(json);
    const productJSONInTrytes = Converter.asciiToTrytes(productJSON);
    const transfers = [{
        value: 0,
        address: receivingAddress,
        message: productJSONInTrytes
    }];
    //sending the transaction
    var response
    await iota.prepareTransfers(seed, transfers)
        .then(trytes => {
            return iota.sendTrytes(trytes, depth, minimumWeightMagnitude);
        })
        .then(bundle => {
            //printing and storing transaction hash
            const txHash = bundle[0].hash
    
            //reading transaction and the message in it from the network
            iota.getBundle(txHash)
            .then(bundle => {
                console.log("Message from the transaction: \n"+JSON.stringify(JSON.parse(Extract.extractJson(bundle),null,4))+"\n");
            })
            .catch(err => {
                console.error(err);
            });

            response = txHash
        })
        .catch(err => {
            console.error(err)
    });  
    return response 
}

module.exports = {
    registerProduct: registerProduct,
    pesticideApplication: pesticideApplication,
    fertilizerApplication: fertilizerApplication
}