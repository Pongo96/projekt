//required packages
const Iota = require('@iota/core');
const Converter = require('@iota/converter');
const Extract = require('@iota/extract-json');

//select a node to connect to
iota = Iota.composeAPI({
    provider: 'https://nodes.devnet.iota.org:443'
});

//defining seed of the sender
const seed = '9XEJ9YLPZFXCPUZBPXC9BFZOIAUPRFHKIVEFZYQEWDGKYIXCBJTTGCPATGGMRSRX9JOYBANGFFTYGIDBP';
const depth = 3;
const minimumWeightMagnitude = 9;

//define receiving address and the message
const receivingAddress = 'HEQLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWORLDHELLOWOR99D';
var lastFertilizerTx = ""
var lastPesticideTx = ""
var lastProductTx = ""

async function pesticideApplication(json, callback) {
    if(!checkPesticideJson(json))
        return {message: "Please check your JSON format and try again."}
    json.pesticides.previousPesticideApplication = lastPesticideTx
    const txHash = await sendTransaction(json)
    lastPesticideTx = txHash
    return {transactionHash: txHash}
}

async function fertilizerApplication(json, callback) {
    if(!checkFertiliserJson(json))
        return {message: "Please check your JSON format and try again."}
    json.fertilisers.previousFertiliserApplication = lastFertilizerTx
    const txHash = await sendTransaction(json)
    lastFertilizerTx = txHash
    return {transactionHash: txHash}
}

async function registerProduct(json) {
    if(!checkProductJson(json))
        return {message: "Please check your JSON format and try again."}
    json.previousProduct = lastProductTx
    const txHash = await sendTransaction(json)
    lastProductTx = txHash
    return {transactionHash: txHash}
}

async function sendTransaction(json) {
    const productJSON = JSON.stringify(json);
    const productJSONInTrytes = Converter.asciiToTrytes(productJSON);
    const transfers = [{
        value: 0,
        address: receivingAddress,
        message: productJSONInTrytes
    }];
    //sending the transaction
    var response
    await iota.prepareTransfers(seed, transfers)
        .then(trytes => {
            return iota.sendTrytes(trytes, depth, minimumWeightMagnitude);
        })
        .then(bundle => {
            //printing and storing transaction hash
            const txHash = bundle[0].hash
    
            //reading transaction and the message in it from the network
            iota.getBundle(txHash)
            .then(bundle => {
                console.log("Message from the transaction: \n"+JSON.stringify(JSON.parse(Extract.extractJson(bundle),null,4))+"\n");
            })
            .catch(err => {
                console.error(err);
            });

            response = txHash
        })
        .catch(err => {
            console.error(err)
    });  
    return response 
}

async function checkStakeholdersAgreement(productHash){
    const json = await getTransaction(productHash);
    var reasons = []
    for(var i =0; i < json.pesticides.length; i++){
        await getTransaction(json.pesticides[i].proofOfPesticideApplication).then(data => {
            pesticide1=json.pesticides[i]
            pesticides2=data['pesticides']
            if (pesticide1['fieldId'] !== pesticides2['fieldId']){
                reasons.push('Stakeholders do not agree on field Id -> '+pesticide1['fieldId'] + ' != ' + pesticides2['fieldId'])
            }else if(pesticide1['typeOfCrop']!== pesticides2['typeOfCrop']){
                reasons.push('Stakeholders do not agree on type of crop -> '+pesticide1['typeOfCrop'] + ' != ' + pesticides2['typeOfCrop'])
            }else if(pesticide1['typeOfPesticide']!== pesticides2['typeOfPesticide']){
                reasons.push('Stakeholders do not agree on type of pesticide -> '+pesticide1['typeOfPesticide'] + ' != ' + pesticides2['typeOfPesticide'])
            }else if(pesticide1['quantityOfPesticide']!== pesticides2['quantityOfPesticide']){
                reasons.push('Stakeholders do not agree on quantity of pesticide -> '+pesticide1['quantityOfPesticide'] + ' != ' + pesticides2['quantityOfPesticide'])
            }else if(pesticide1['pesticideApplicationTime']!== pesticides2['pesticideApplicationTime']){
                reasons.push('Stakeholders do not agree on pesticide application time -> '+pesticide1['pesticideApplicationTime'] + ' != ' + pesticides2['pesticideApplicationTime'])
            }
        }).catch(err => {
            console.error(err);
        });
    }

    for(var i =0; i < json.fertilisers.length; i++){
        await getTransaction(json.fertilisers[i].proofOfFertiliserApplication).then(data => {
            fertilizer1 = json.fertilisers[i]
            fertilizer2 = data['fertilisers']
            if (fertilizer1['fieldId'] !== fertilizer2['fieldId']){
                reasons.push('Stakeholders do not agree on field Id -> '+fertilizer1['fieldId'] + ' != ' + fertilizer2['fieldId'])
            }else if(fertilizer1['typeOfCrop'] !== fertilizer2['typeOfCrop']){
                reasons.push('Stakeholders do not agree on type of crop -> '+fertilizer1[typeOfCrop] + ' != ' + fertilizer2[typeOfCrop])
            }else if(fertilizer1['typeOfFertiliser'] !== fertilizer2['typeOfFertiliser']){
                reasons.push('Stakeholders do not agree on type of fertiliser -> '+fertilizer1['typeOfFertiliser'] + ' != ' + fertilizer2['typeOfFertiliser'])
            }else if(fertilizer1['quantityOfFertiliser'] !== fertilizer2['quantityOfFertiliser']){
                reasons.push('Stakeholders do not agree on quantity of fertiliser -> '+fertilizer1['quantityOfFertiliser'] + ' != ' + fertilizer2['quantityOfFertiliser'])
            }else if(fertilizer1['fertiliserApplicationTime'] !== fertilizer2['fertiliserApplicationTime']){
                reasons.push('Stakeholders do not agree on fertiliser fpplication time -> '+fertilizer1['fertiliserApplicationTime'] + ' != ' + fertilizer2['fertiliserApplicationTime'])
            }
        }).catch(err => {
            console.error(err);
        });   
    }
    if (reasons.length === 0){
        reasons.push('Stakeholders agree on this transaction')
    }
    console.log(reasons)
    return {message : reasons}
}
async function getTransaction(hash){
    const tailTransactionHash = hash;
    var response;
    await iota.getBundle(tailTransactionHash)
    .then(bundle => {
        const msg = JSON.parse(Extract.extractJson(bundle));
        response = msg;
    })
    .catch(err => {
        console.error(err);
    });
    return response;
}

function checkPesticideJson(json) {
    if(json.pesticides && json.pesticides.stakeholder && json.pesticides.fieldId &&
           json.pesticides.typeOfCrop && json.pesticides.typeOfPesticide && json.pesticides.quantityOfPesticide
           && json.pesticides.pesticideApplicationTime && json.pesticides.fieldId && json.pesticides.fieldId && 
           json.pesticides.previousPesticideApplication == "")
        return true
    else return false
}

function checkFertiliserJson(json) {
    if(json.fertilisers && json.fertilisers.stakeholder && json.fertilisers.fieldId &&
           json.fertilisers.typeOfCrop && json.fertilisers.typeOfFertiliser && json.fertilisers.quantityOfFertiliser
           && json.fertilisers.fertiliserApplicationTime &&
           json.fertilisers.previousFertiliserApplication == "")
           return true
    else return false
}

function checkProductJson(json) {
    if(json.productName && json.weight && json.packageId &&
           json.dateOfHarvest && json.dateOfPackaging && json.countryOfOrigin
           && json.pesticides && json.fertilisers) {
           for (i in json.pesticides) {
                if(json.pesticides[i].fieldId && json.pesticides[i].typeOfCrop && json.pesticides[i].typeOfPesticide && 
                    json.pesticides[i].quantityOfPesticide && json.pesticides[i].pesticideApplicationTime && 
                    json.pesticides[i].proofOfPesticideApplication)
                    continue
                else return false
           }
           for (i in json.fertilisers) {
                if(json.fertilisers[i].fieldId && json.fertilisers[i].typeOfCrop && json.fertilisers[i].typeOfFertiliser && 
                    json.fertilisers[i].quantityOfFertiliser && json.fertilisers[i].fertiliserApplicationTime && 
                    json.fertilisers[i].proofOfFertiliserApplication)
                    continue
                else return false
           }
           return true
    } 
    else return false
    }


module.exports = {
    registerProduct: registerProduct,
    pesticideApplication: pesticideApplication,
    fertilizerApplication: fertilizerApplication,
    checkStakeholdersAgreement: checkStakeholdersAgreement,
    getTransaction: getTransaction
}