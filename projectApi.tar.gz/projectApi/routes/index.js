var express = require('express');
var router = express.Router();
var functionsHandler = require('../functions/functions');
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/pesticideApplication', async function(req, res, next) {
  const applicationJSON = req.body
  const response = await functionsHandler.pesticideApplication(applicationJSON)
  res.status(200).json(response).send();
});

router.get('/fertilizerApplication', async function(req, res, next) {
  const applicationJSON = req.body
  const response = await functionsHandler.fertilizerApplication(applicationJSON)
  res.status(200).json(response).send();
});

router.get('/registerProduct', async function(req, res, next) {
  const productJSON = req.body
  const response = await functionsHandler.registerProduct(productJSON)
  res.status(200).json(response).send();

});

// /getTransactionConfirmationCUS?transactionId=0xtransaction&value=Q
router.get('/getTransactionConfirmationCUS', async function(req, res, next) {
  const transactionId = req.param('transactionId').trim();
  if(validateTxHash(transactionId)){
    const value = req.param('value');
    if(validateNumber(value)){
      const response = await functionsHandler.getTransactionConfirmationCUS(transactionId, value);
      res.status(200).send(response);
    }
    else
      res.status(400).send({transactionStatus: "Error: Sent value is not a number."});
  }
  else {
    res.status(400).send({transactionStatus: "Error: Transaction id does not meet the standards, check what you are sending. TxId must have 66 charachters starting with 0x."});
  }
});

function validateTxHash(address){
  return /^0x([A-Fa-f0-9]{64})$/.test(address);
}
/*
// /fertilizerApplication?applicatorAddress=applicatorAddress&applicatorSeed=applicatorSeed
router.get('/fertilizerApplication', async function(req, res, next) {
  const applicatorAddress = req.query["applicatorAddress"]
  const applicatorSeed = req.query["applicatorSeed"]
  const applicationJSON = req.body
  console.log(applicatorAddress)
  console.log(applicatorSeed)
  console.log(applicationJSON)
});
*/

function validateNumber(num){
  return !isNaN(num)
}

module.exports = router;
