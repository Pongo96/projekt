var express = require('express');
var router = express.Router();
var functionsHandler = require('../functions/functions');
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/pesticideApplication', async function(req, res, next) {
  const applicationJSON = req.body
  const response = await functionsHandler.pesticideApplication(applicationJSON)
  res.status(200).json(response).send();
});

router.get('/fertilizerApplication', async function(req, res, next) {
  const applicationJSON = req.body
  const response = await functionsHandler.fertilizerApplication(applicationJSON)
  res.status(200).json(response).send();
});

router.get('/registerProduct', async function(req, res, next) {
  const productJSON = req.body
  const response = await functionsHandler.registerProduct(productJSON)
  res.status(200).json(response).send();
});

// /checkStakeholdersAgreement?productHash=productHash
router.get('/checkStakeholdersAgreement', async function(req, res, next) {
  const productHash = req.param('productHash');
  const response = await functionsHandler.checkStakeholdersAgreement(productHash)
  res.status(200).json(response).send();
});

// /products?productHash={productHash}
router.get('/products', async function(req, res, next){
  const productHash = req.param('productHash');
  const response = await functionsHandler.getTransaction(productHash)
  res.status(200).json(response).send();
});

module.exports = router;
